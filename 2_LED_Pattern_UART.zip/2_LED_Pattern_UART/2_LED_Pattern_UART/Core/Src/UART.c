/*
 **************************************************************************
 * @file 		UART.c
 * @brief 		UART and its operations
 **************************************************************************
 *
 */
#include "UART.h"

/*************************************************************************
 *@brief Using HAL APIs inside wrapper to perform Loopback
 *@param none
 *@retval void
 *
 **************************************************************************/
void UART_LoopBack()
{
if(HAL_OK == HAL_UART_Receive(&huart1,(uint8_t *)&x, sizeof(x),2000))
  {
	HAL_UART_Transmit(&huart1,(uint8_t *)&x, sizeof(x),2000);
  }
/* USER CODE BEGIN 3 */
}

/*************************************************************************
 *@brief Using HAL APIs inside wrapper to display Options
 *@param none
 *@retval void
 *
 **************************************************************************/
void UART_Display()
{
	HAL_UART_Transmit(&huart1," \n\r 0   LEDs are in OFF state \
																\n\r 1   LEDs are in ON state \
																\n\r 2   LEDs are in Toggle state \
																\n\r 3   LEDs toggle in different state\n ",200,2000);
}

/*************************************************************************
 *@brief Using HAL api inside wrapper to transmit data over UART.
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void UART_Transmit(UART_HandleTypeDef *UART)
{
char Buffer2[31];
sprintf(Buffer2,"\n\rTransfered Data = %s",TxData);
HAL_UART_Transmit(UART,(uint8_t *)Buffer2,sizeof(Buffer2),100);
HAL_Delay(100);
}

/*************************************************************************
 *@brief Using HAL api inside wrapper to receive data over UART.
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void UART_Receive(UART_HandleTypeDef *UART)
{
HAL_UART_Receive(&huart1,RxDATA,sizeof(RxDATA),2000);
HAL_Delay(50);
}

/*************************************************************************
 *@brief Using UART Interrupt function inside wrapper gets called when we receive data.
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void UART_Receive_Interrupt_CallBack(UART_HandleTypeDef *UART){
HAL_UART_Receive_IT(UART,RxDataCallback,sizeof(RxDataCallback));
}

/*************************************************************************
 *@brief Callback fuction to transmit data over UART
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(huart);

  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_UART_RxCpltCallback can be implemented in the user file.
   */
	HAL_UART_Transmit(huart,RxDataCallback,sizeof(RxDataCallback),1);
}

/*************************************************************************
 *@brief Using printf() function inside wrapper to transmit data over UART.
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void Printf_Function(UART_HandleTypeDef *UART){
#ifdef __GNUC__
  /* With GCC, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif
printf("\n\rPrintf Output=%s\n",PRINTF);
	HAL_Delay(500);
}

/*************************************************************************
 *@brief Function Prototype for Printf Functionality
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the EVAL_COM1 and Loop until the end of transmission */
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
  return ch;
}

/*************************************************************************
 *@brief Display Data with different datatypes
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void UART_Different_Datatypes(UART_HandleTypeDef *UART){
	char Buffer[64];
	printf("\n\rDiffrent Datatypes:");
	sprintf(Buffer,"\n\rInteger=%d\t\n\rOctal=%o\t\n\rHex=%x\t\n\rFloat=%f\t\n\rString=%s\n",Integer,Integer,Integer,Float,String);
	HAL_UART_Transmit(UART,(uint8_t *)Buffer,sizeof(Buffer),100);
}

/*************************************************************************
 *@brief Function toggles LED in different states according to user inputs.
 *@param UART Handler
 *@retval void
 *
 **************************************************************************/
void UART_LED_Pattern()
{
	HAL_UART_Receive(&huart1,(uint8_t *)&Data,sizeof(RxData),1000);

				switch(Data)
					{
				case 0x30:
					 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_SET);
					 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_SET);
					 HAL_Delay(1000);
					 break;
				case 0x31:
						HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_RESET);
						HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_RESET);
						HAL_Delay(1000);
						break;
				case 0x32:
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_RESET);
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_RESET);
							 HAL_Delay(1000);
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_SET);
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_SET);
							 HAL_Delay(1000);
							 break;
				case 0x33:
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_RESET);
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_RESET);
							 HAL_Delay(100);
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_SET);
							 HAL_GPIO_WritePin(GPIOB,GPIO_PIN_2,GPIO_PIN_SET);
							 HAL_Delay(100);
							 break;
}

}
