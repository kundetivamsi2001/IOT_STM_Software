#ifndef _uart_H_
#define _uart_H_

/*
 **************************************************************************
 * @file 		UART.c
 * @brief 		UART and its operations
 **************************************************************************
 *
 */

/*************************************************************************
Include Files
 **************************************************************************/
#include "stm32g4xx_hal.h"
#include "main.h"
#include "stdio.h"


/*************************************************************************
Private Defines
 **************************************************************************/
#define Integer 22
#define String "IOT"
#define Float 2.2
#define TxData ""
#define PRINTF "Printf is in use"


/*************************************************************************
Handlers
 **************************************************************************/
extern UART_HandleTypeDef huart1;

/*************************************************************************
Variables
 **************************************************************************/
uint8_t RxDataCallback[1];
uint8_t RxDATA[4]={0};
uint8_t x=10;

uint8_t Data=10,value;
uint8_t RxData[4]={0};
char Buffer1[31];

//char Buffer1[31];

/*************************************************************************
Wrapper Functions
 **************************************************************************/
void UART_Transmit(UART_HandleTypeDef *UART);
void UART_Receive(UART_HandleTypeDef *UART);
void UART_Receive_Interrupt_CallBack(UART_HandleTypeDef *UART);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void Printf_Function(UART_HandleTypeDef *UART);
void UART_Different_Datatypes(UART_HandleTypeDef *UART);
void UART_LoopBack(void);
void UART_Display(void);
void UART_LED_Pattern(void);
#endif
